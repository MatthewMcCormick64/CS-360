package com.example.matt_mccormick_project_2_option_3;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class login_Activity extends AppCompatActivity {

    private EditText editTextUsername, editTextPassword;
    private Button buttonLogin, buttonRegister;
    private SQLiteDatabase db;
    private User_Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_1_login_main);

        // UI elements
        editTextUsername = findViewById(R.id.userID); //userid input from log in saved to variable
        editTextPassword = findViewById(R.id.userPassword); //userpassword input from log in saved to variable
        buttonLogin = findViewById(R.id.userLogin); //input button from log in to initiate log in
        buttonRegister = findViewById(R.id.newUser); //input button from log in to save new user informaiton to database

        // open database
        dbHelper = new User_Database(this); //data base to store user information
        db = dbHelper.getWritableDatabase(); //setting database information to variable

        // login button click
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString().trim(); //updating username to string and variable
                String password = editTextPassword.getText().toString().trim(); //updating password to string and variable

                // adding if statement to verify if user has implement credentials
                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(login_Activity.this, "Username and password cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                // adding if statement if user credentials are correct
                if (checkLogin(username, password)) {
                    Toast.makeText(login_Activity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    // intent statement to transistion to new activity screen if credentials are correct
                    Intent intent = new Intent(login_Activity.this, User_Weight_Login_Activity.class);
                    startActivity(intent);
                    finish();
                    //adding else statement if credentials are not correct
                } else {
                    Toast.makeText(login_Activity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // register button click
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString().trim(); //updating username to string and variable
                String password = editTextPassword.getText().toString().trim(); //updating password to string and variable
                // adding if statement to verify if user has implement credentials
                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(login_Activity.this, "Username and password cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                // adding if statement if user credentials meet requirements
                if (registerUser(username, password)) {
                    Toast.makeText(login_Activity.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                }
                //adding else statement if credentials are not meeting requirements
                else {
                    Toast.makeText(login_Activity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // check login credentials
    private boolean checkLogin(String username, String password) {
        String[] columns = {"username"};
        String selection = "username=? AND password=?";
        String[] selectionArgs = {username, password};
        Cursor cursor = db.query("users", columns, selection, selectionArgs, null, null, null);
        // if credentials are zero boolean sends a not true statement
        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }

    //  register a new user
    private boolean registerUser(String username, String password) {
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        long result = db.insert("users", null, values);
        return result != -1;
    }
}