package com.example.matt_mccormick_project_2_option_3;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class User_Database extends SQLiteOpenHelper {
    // database to store user information
    private static final String DATABASE_NAME = "userDatabase.db";
    private static final int DATABASE_VERSION = 1;

    public User_Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // create users table log in information
        String createUsersTable = "CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "username TEXT," +
                "password TEXT)";
        db.execSQL(createUsersTable);

        // create weight entries table information
        String createWeightEntriesTable = "CREATE TABLE weight_entries (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "date TEXT," +
                "weight TEXT)";
        db.execSQL(createWeightEntriesTable);

        // create goal weight information
        String createGoalWeightsTable = "CREATE TABLE goal_weights (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "goal_weight TEXT)";
        db.execSQL(createGoalWeightsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // drop tables if they exist and create them again
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weight_entries");
        db.execSQL("DROP TABLE IF EXISTS goal_weights");
        onCreate(db);
    }
}