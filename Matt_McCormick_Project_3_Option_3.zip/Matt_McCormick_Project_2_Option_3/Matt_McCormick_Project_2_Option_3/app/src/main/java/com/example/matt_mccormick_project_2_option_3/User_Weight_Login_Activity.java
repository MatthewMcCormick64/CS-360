package com.example.matt_mccormick_project_2_option_3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import android.content.ContentValues;

import androidx.appcompat.app.AppCompatActivity;

public class User_Weight_Login_Activity extends AppCompatActivity {

    private EditText entryDate, userWeight, goalWeightInput;
    private Button addWeightButton, saveGoalButton, goToSmsButton;
    private TableLayout tableLayout;
    private SQLiteDatabase db;
    private User_Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2_database_main);

        // UI elements
        entryDate = findViewById(R.id.entry_Date); // passes input to variable
        userWeight = findViewById(R.id.user_Weight); // passes input to variable
        goalWeightInput = findViewById(R.id.goal_weight_input); // passes input to variable
        addWeightButton = findViewById(R.id.add_Weight_button); // passes input to variable
        saveGoalButton = findViewById(R.id.save_goal_button); // passes input to variable
        goToSmsButton = findViewById(R.id.go_to_sms_button); // passes input to variable
        tableLayout = findViewById(R.id.tableLayout); // passes input to variable

        //  open database
        dbHelper = new User_Database(this);
        db = dbHelper.getWritableDatabase();

        // handle add weight button click
        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = entryDate.getText().toString();
                String weight = userWeight.getText().toString();
                // adding if statement to verify if user has updated table correctly
                if (date.isEmpty() || weight.isEmpty()) {
                    Toast.makeText(User_Weight_Login_Activity.this, "Please enter both date and weight", Toast.LENGTH_SHORT).show();
                }

                else {
                    // adding if statement to verify if user has updated table correctly
                    if (addWeightEntry(date, weight)) {
                        Toast.makeText(User_Weight_Login_Activity.this, "Weight entry added", Toast.LENGTH_SHORT).show();
                        displayEntries();  // refresh the table to show new entry
                        entryDate.setText("");  // clear the input fields
                        userWeight.setText("");
                    } else {
                        Toast.makeText(User_Weight_Login_Activity.this, "Failed to add weight entry", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // handle save goal button click
        saveGoalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String goalWeight = goalWeightInput.getText().toString();
                if (goalWeight.isEmpty()) {
                    Toast.makeText(User_Weight_Login_Activity.this, "Please enter your goal weight", Toast.LENGTH_SHORT).show();
                } else {
                    if (saveGoalWeight(goalWeight)) {
                        Toast.makeText(User_Weight_Login_Activity.this, "Goal weight saved", Toast.LENGTH_SHORT).show();
                        goalWeightInput.setText("");  // clear the input field
                    } else {
                        Toast.makeText(User_Weight_Login_Activity.this, "Failed to save goal weight", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // handle go to SMS activity button click
        goToSmsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(User_Weight_Login_Activity.this, SMS_Activity.class);
                startActivity(intent);
            }
        });

        // display existing entries when activity is created
        displayEntries();
    }

    // method to add weight entry to the database
    private boolean addWeightEntry(String date, String weight) {
        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("weight", weight);
        long result = db.insert("weight_entries", null, values);
        return result != -1;
    }

    // method to save goal weight to the database
    private boolean saveGoalWeight(String goalWeight) {
        ContentValues values = new ContentValues();
        values.put("goal_weight", goalWeight);
        long result = db.insert("goal_weights", null, values);
        return result != -1;
    }

    // method to display weight entries in the TableLayout
    private void displayEntries() {
        tableLayout.removeAllViews();  // Clear existing views

        Cursor cursor = db.query("weight_entries", null, null, null, null, null, null);
        while (cursor.moveToNext()) {
            //this section of code below is to allow user to see full historic data of weight entries
            String date = cursor.getString(cursor.getColumnIndex("date"));
            String weight = cursor.getString(cursor.getColumnIndex("weight"));

            TableRow row = new TableRow(this);

            TextView dateView = new TextView(this);
            dateView.setText(date);
            dateView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 2));

            TextView weightView = new TextView(this);
            weightView.setText(weight);
            weightView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 2));
            //adding in a delete button for each row
            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (deleteEntry(date)) {
                        Toast.makeText(User_Weight_Login_Activity.this, "Entry deleted", Toast.LENGTH_SHORT).show();
                        displayEntries();  // Refresh the table
                    } else {
                        Toast.makeText(User_Weight_Login_Activity.this, "Failed to delete entry", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            row.addView(dateView);
            row.addView(weightView);
            row.addView(deleteButton);

            tableLayout.addView(row);
        }
        cursor.close();
    }

    // method to delete a weight entry from the database
    private boolean deleteEntry(String date) {
        int rowsDeleted = db.delete("weight_entries", "date=?", new String[]{date});
        return rowsDeleted > 0;
    }
}