package com.example.matt_mccormick_project_2_option_3;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //adding intent statement to control activity process
        Intent intent = new Intent(MainActivity.this, login_Activity.class);
        //starts activity based on what intent is passed in
        startActivity(intent);
    }
}
